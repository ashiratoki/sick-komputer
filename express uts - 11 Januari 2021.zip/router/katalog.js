const express = require('express'); //Mengimpor modul express lalu menyimpannya di const express
const router = express.Router(); // Instansi objek express untuk menjalankan route secara modular
const katalogController = require('../controllers/katalog');
const katalog = require('../controllers/katalog');


router.route('/katalog') // syntax .app diganti dengan syntax router
    .get(katalogController.index)
    .post(katalogController.create)
router.route('/katalog/update').post(katalogController.baharui)
router.get('/katalog/create', katalogController.tambah)
router.get('/katalog/:id', katalogController.show)
router.get('/katalog/hapus/:id', katalogController.hapus)
router.route('/katalog/update/:_id/:id/:namaBarang/:jenisBarang/:password').get(katalogController.renderUpdate)
//UPDATE DATA
router.put('/katalog/:idBarang', katalogController.update)
//HAPUS DATA
router.delete('/katalog/:idBarang', katalogController.delete)

module.exports = router; //Modul ini akan diekspor dengan route khusus untuk (URL:/katalog),
                        //dan sudah bisa diexport